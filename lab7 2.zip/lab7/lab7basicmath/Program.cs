﻿namespace ConsoleApp2
{

    internal class Program
    {
        static void Main(string[] args)
        {
            /*1.	Create a project named BasicMath.
        2.	Add a class named BasicMath that includes four methods: 
        •	add
        •	subtract
        •	divide
        •	multiply
        3.	Ensure that each method takes two double arguments and returns the corresponding operation result.
        4.	Create another project and relate it to the first project.
        5.	Write test cases that test all four methods to ensure they work as expected.
        The expected test run should appear as follows:
        */
            BasicMath basicMath = new BasicMath() { };

            Console.WriteLine("Enter first number:");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter second number:");
            double num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Addition Result: {basicMath.addMethod(num1, num2)}");
            Console.WriteLine($"Subtraction Result: {basicMath.subtractMethod(num1, num2)}");
            Console.WriteLine($"Divide Result: {basicMath.divideMethod(num1, num2)}");
            Console.WriteLine($"Multiply Result: {basicMath.multiplyMethod(num1, num2)}");
        }
    }
}