﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class BasicMath
    {
        public double Add {  get; set; }
        public double Subtract { get; set; }
        public double Divide { get; set; }
        public double Multiply { get; set; } 

        public BasicMath(double add, double subtract, double divided, double multiply) 
        {
            Add = add;
            Subtract = subtract;
            Divide = divided;
            Multiply = multiply;
        }

        public BasicMath()
        {
        }

        public double addMethod(double a, double b)
        {
            return a + b;
        }

        public double subtractMethod(double a, double b)
        {
            return a - b;
        }

        public double divideMethod(double a, double b)
        {
            return a / b;
        }

        public double multiplyMethod(double a, double b)
        {
            return a * b;
        }
        /*1.	Create a project named BasicMath.
        2.	Add a class named BasicMath that includes four methods: 
        •	add
        •	subtract
        •	divide
        •	multiply
        3.	Ensure that each method takes two double arguments and returns the corresponding operation result.
        4.	Create another project and relate it to the first project.
        5.	Write test cases that test all four methods to ensure they work as expected.
        The expected test run should appear as follows:
        */

    }
}
