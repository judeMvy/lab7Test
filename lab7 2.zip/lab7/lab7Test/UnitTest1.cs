using System.Diagnostics;

namespace lab7Test
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            Debug.WriteLine("Setup run...");
        }

        [Test]
        public void Test1()
        {
            Debug.WriteLine("Test 1: Add method");
            Assert.Pass();
        }

        [Test]
        public void Test2()
        {
            Debug.WriteLine("Test 2: Subtract method");
            Assert.Pass();
        }

        [Test]
        public void Test3()
        {
            Debug.WriteLine("Test 3: Divide method");
            Assert.Pass();
        }

        [Test]
        public void Test4()
        {
            Debug.WriteLine("Test 4: Multiply method");
            Assert.Pass();
        }

        [TearDown]
        public void TearDown() 
        {
            Debug.WriteLine("Running teardown...");
        }
    }
}